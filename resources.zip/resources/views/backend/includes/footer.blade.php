<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-sm-none d-md-block">
        Develop By <a href="https://staritltd.com/"> Star IT Ltd</a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2018-{{date('Y')}} <a href="#">Mudi Hat</a>.</strong> All rights reserved.
</footer>
